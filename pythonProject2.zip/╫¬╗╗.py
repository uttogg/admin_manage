import datetime

timestamp = 1688483835
dt = datetime.datetime.fromtimestamp(timestamp)
print(dt)
